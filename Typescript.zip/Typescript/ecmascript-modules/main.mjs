console.log("Main Module Started!");
import { addition, multiplication } from "./app/basic-math";
import customerObj1 from "./app/customer.mjs";
import customerObj2 from "./app/customer.mjs";

customerObj1.firstName="Manish";
customerObj1.lastName="Kaushik";
customerObj1.city="Bangalore";
console.log(customerObj1.getCustomerInfo());
console.log(customerObj2.getCustomerInfo());
// const c1=new Customer();
// const c2=new Customer();

console.log(`Addition is - ${addition(100,200)}`);
console.log(`Multiplication is - ${multiplication(100,200)}`);
console.log("Main Module Loaded!");
