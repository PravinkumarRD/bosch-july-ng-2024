console.log('Customer Module Started!');
class Customer{
    constructor(){
        console.log('Customer Constructor Executed!');
    }
    firstName;
    lastName;
    city;
    getCustomerInfo(){
        return `Customer ${this.firstName} ${this.lastName} lives in city ${this.city}!`
    }
}

export default new Customer();

console.log('Customer Module Loaded!');