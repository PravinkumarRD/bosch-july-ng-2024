console.log("Basic Math Module Started!");

import { square } from "./adv-math.mjs";

export function addition(num1, num2) {
  return num1 + num2;
}
function subtraction(num1, num2) {
  return num1 - num2;
}
export function multiplication(num1, num2) {
  return num1 * num2;
}
function division(num1, num2) {
  return num1 / num2;
}

console.log(`Squre of 67 is ${square(67)}`);

console.log("Basic Math Module Loaded!");
