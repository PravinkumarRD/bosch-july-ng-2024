console.log("Advance Math Module Started!");

export function square(num) {
  return num * num;
}
function squareRoot(num){
    return Math.sqrt(num);
}

console.log("Advance Math Module Loaded!");
