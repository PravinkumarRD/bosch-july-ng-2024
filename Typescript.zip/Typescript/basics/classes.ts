//ECMAScript - 
//1) To define private data member, your use # keyword

//In Typescript - Access Modifiers - Private, Public and Protected

// class Person {
//     firstName: string;
//     lastName: string;
//     city: string;
//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }
// class Person {
//     constructor(fname?: string, lname?: string, city?: string) {
//         console.log('Person Class Constructor Executed');
//         this.firstName = fname;
//         this.lastName = lname;
//         this.city = city;
//     }
//     firstName: string;
//     lastName: string;
//     city: string;
//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }

//Constructor Properties

//Generalization-To-Specialization

abstract class Person {
    constructor(public firstName?: string, public lastName?: string, private city?: string) {
        console.log('Person Class Constructor Executed');

    }
    private _address: string;
    get address() {
        //Manipulations
        return this._address;
    }
    set address(v: string) {
        //Validation
        this._address = v;
    }
    getPersonInfo(): string {
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
//Relationship - IS-A Customer IS-A Person
class Customer extends Person {
    constructor(){
        super();//Must be the first line of code
    }
    customerId:number;
}

//const person: Person = new Person("Pravinkumar", "R. D.", "Pune");
const person: Customer = new Customer();
// person.firstName="Manish";
// person.lastName="Sharma";
// person.city="Delhi";
console.log(person.getPersonInfo());

console.log(typeof (Person))

class A {
    x: number;
}
class B extends A {
    y: number;
}
class C extends B {
    z:number;
}
const c1:C=new C();
