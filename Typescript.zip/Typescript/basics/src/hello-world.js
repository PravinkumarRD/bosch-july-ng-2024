console.log("Welcome To Typescript Basics Training!!!");
//# sourceMappingURL=hello-world.js.map