//ECMAScript - 
//1) To define private data member, your use # keyword
//In Typescript - Access Modifiers - Private, Public and Protected
// class Person {
//     firstName: string;
//     lastName: string;
//     city: string;
//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }
// class Person {
//     constructor(fname?: string, lname?: string, city?: string) {
//         console.log('Person Class Constructor Executed');
//         this.firstName = fname;
//         this.lastName = lname;
//         this.city = city;
//     }
//     firstName: string;
//     lastName: string;
//     city: string;
//     getPersonInfo(): string {
//         return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
//     }
// }
//Constructor Properties
//Generalization-To-Specialization
class Person {
    firstName;
    lastName;
    city;
    constructor(firstName, lastName, city) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.city = city;
        console.log('Person Class Constructor Executed');
    }
    _address;
    get address() {
        //Manipulations
        return this._address;
    }
    set address(v) {
        //Validation
        this._address = v;
    }
    getPersonInfo() {
        return `Person ${this.firstName} ${this.lastName} lives in city ${this.city}!`;
    }
}
//Relationship - IS-A Customer IS-A Person
class Customer extends Person {
    constructor() {
        super(); //Must be the first line of code
    }
    customerId;
}
//const person: Person = new Person("Pravinkumar", "R. D.", "Pune");
const person = new Customer();
// person.firstName="Manish";
// person.lastName="Sharma";
// person.city="Delhi";
console.log(person.getPersonInfo());
console.log(typeof (Person));
class A {
    x;
}
class B extends A {
    y;
}
class C extends B {
    z;
}
const c1 = new C();
//# sourceMappingURL=classes.js.map