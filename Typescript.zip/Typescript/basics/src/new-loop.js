const MyOfficies = ["Bangalore", "Delhi", "Mumbai", "Pune"];
for (let i = 0; i < MyOfficies.length; i++) {
    if (MyOfficies[i] == "Mumbai")
        break;
    console.log(MyOfficies[i]);
}
console.log('');
MyOfficies.forEach(function (city) {
    if (city == "Mumbai")
        return;
    console.log(city);
});
console.warn('');
//for-of loop - Iterator Object - ECMAScript 2015
for (let city of MyOfficies) {
    if (city == "Mumbai")
        break;
    console.log(city);
}
//Generator Function
function* generateOrderNumbers(startNo, endNumber) {
    // yield 1001;
    // yield 1002;
    // yield 1003;
    while (startNo < endNumber) {
        yield startNo * 2;
        startNo++;
    }
}
for (const ordNo of generateOrderNumbers(1, 10)) {
    console.log(ordNo);
}
//# sourceMappingURL=new-loop.js.map