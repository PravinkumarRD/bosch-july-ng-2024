//Type Inference - Typescript compiler upon declaration and initiailzation will decide the type of the varaible and pickup an appropriate type from type system and retain that type throughout the life of the program/application
let fullName = "Pravinkumar R. D.";
//fullName=100.90;//Error
let num1 = 900;
num1 = 890;
// num1=true;
// num1="Pravin"

//Is there any type inference - YES - to type any like JavaScript var [Try not to use this]
//let isLoggedIn;

//Type Annotations
let isLoggedIn: number | boolean;
isLoggedIn = false;
isLoggedIn = 0;
//isLoggedIn="No";

//Type Annotations for Functions

function addition(num1: number, num2: number): number {
    return num1 + num2;
}
console.log(addition(100, 200));
function hrMessage(message: string) {
    return "100";
    console.log(message);
}
hrMessage("Welcome To Bosch!");

//Premitive type [string, number, boolean]
const PI = 3.14;
//Reference Types [Object/Array]

const Offices: string[] = ["Bangalore", "Chennai", "Mumbai"];
Offices.push("Pune");
console.log(Offices);
//Offices=[]; //error

const BoschCustomer = {
    customerId: 23782,
    contactName: 'Alisha C.',
    city: 'Mumbai'
}

BoschCustomer.city="Pune";
console.log(BoschCustomer);
//BoschCustomer={};
