//Calculate sales net profit = incoming money - outgoing money
//COGS - outgoing, expense - outgoing, actualSales - incoming, gst- outing money

// function salesNetProfit(cogs: number, expense: number, actualSales: number, gstPercent: number): number {
//     const gstAmount: number = actualSales * gstPercent / 100;
//     return actualSales - (cogs + expense + gstAmount);
// }

//Default Parameter
function salesNetProfit(cogs: number, expense: number = 15000, actualSales: number, gstPercent: number = 0): number {
    const gstAmount: number = actualSales * gstPercent / 100;
    return actualSales - (cogs + expense + gstAmount);
}

//salesNetProfit(12000,13000,150000,18);

console.log(`Sales Net Profit of Bosch for Q-1 is INR ${salesNetProfit(12000, undefined, 150000, 18)}`);
console.log(`Sales Net Profit of Bosch without GST for Q-1 is INR ${salesNetProfit(12000, 13000, 150000)}`);

//Optional Parameters 
function add(num1: number, num2: number, num3?: number): number {
    if (!num3) num3 = 0;
    return num1 + num2 + num3;
}

console.log(add(100, 200, 900));

//REST Parameter - will pack the comma separated values in an array
//Rules - REST parameter must be last parameter in a parameters list and only one rest parameter is allowed

function printBoschCities(country: string, ...cities: string[]): void {
    console.log(country);
    console.log(cities);
}

const MyWorkingCities: string[] = ["Pune", "Delhi", "Mumbai", "Bangalore", "Hyderabad"];

printBoschCities("India", "Pune", "Delhi", "Mumbai");
//SPREAD - Operator which will unpack the collection values [Array/Object]
printBoschCities("India", ...MyWorkingCities);
printBoschCities("India", "Hyderabad", "Bangalore");

//SPREAD with Object
const PizzaHutOrder = {
    customerId: 23892,
    orderId: 8983,
    orderDate: new Date(),
    price: 340,
    status: 'PizzaHut has accepted your order!'
}
const PizzaInOven ={
    ...PizzaHutOrder,
    status:'Your pizza is getting baked in oven!'
} //Copy

console.log(PizzaHutOrder);
console.log(PizzaInOven);