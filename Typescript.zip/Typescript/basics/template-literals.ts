const BoschPrimeCustomer = {
    customerId: 3499,
    contactName: 'Manish Kaushik',
    city: 'Bangalore'
}

//Customer with Id 3499 having name 
//Manish Kaushik lives in city Bangalore!
console.log("Customer with Id "+BoschPrimeCustomer.customerId + " having name \n\t" + BoschPrimeCustomer.contactName + " lives in city " + BoschPrimeCustomer.city + "!");

//Template Literals/Expressions
//Syntax - Backtick syntax - `Your string ${expression}`
console.log(`Customer Id with ${BoschPrimeCustomer.customerId} having name 
        ${BoschPrimeCustomer.contactName} lives in city ${BoschPrimeCustomer.city}!`);

let row=
    `
        <tr>
            <td>${BoschPrimeCustomer.city}</td>
            <td></td>
            <td></td>
        </tr>
    `;